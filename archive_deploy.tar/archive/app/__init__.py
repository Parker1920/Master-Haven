"""Travelers Archive — FastAPI application package."""

__version__ = "0.6.0"
