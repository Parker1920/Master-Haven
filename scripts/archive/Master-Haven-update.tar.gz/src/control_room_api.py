from fastapi import FastAPI, UploadFile, File, WebSocket, WebSocketDisconnect, HTTPException, Request
from fastapi.responses import JSONResponse, FileResponse, HTMLResponse, RedirectResponse
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Dict
from pathlib import Path
from datetime import datetime, timedelta
from contextlib import contextmanager
import json
import sqlite3
import os
import re
import asyncio
import logging
from fastapi.staticfiles import StaticFiles

# Import glyph decoder
try:
    from glyph_decoder import (
        decode_glyph_to_coords,
        encode_coords_to_glyph,
        validate_glyph_code,
        format_glyph,
        GLYPH_IMAGES
    )
except ImportError:
    from src.glyph_decoder import (
        decode_glyph_to_coords,
        encode_coords_to_glyph,
        validate_glyph_code,
        format_glyph,
        GLYPH_IMAGES
    )

app = FastAPI()
logger = logging.getLogger('control.room')

# Basic CORS - adjust for dev
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Determine Haven UI directory
HAVEN_UI_DIR = Path(os.getenv('HAVEN_UI_DIR', Path(__file__).resolve().parents[1] / 'Haven-UI'))
DATA_JSON = HAVEN_UI_DIR / 'data' / 'data.json'
PHOTOS_DIR = HAVEN_UI_DIR / 'photos'
LOGS_DIR = HAVEN_UI_DIR / 'logs'

# Ensure directories exist
HAVEN_UI_DIR.mkdir(parents=True, exist_ok=True)
(HAVEN_UI_DIR / 'data').mkdir(parents=True, exist_ok=True)
PHOTOS_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)

# Mount static folders (so running uvicorn directly also serves the SPA)
photos_dir = HAVEN_UI_DIR / 'photos'
if photos_dir.exists():
    app.mount('/haven-ui-photos', StaticFiles(directory=str(photos_dir)), name='haven-ui-photos')

ui_static_dir = HAVEN_UI_DIR / 'static'
ui_dist_dir = HAVEN_UI_DIR / 'dist'
if ui_dist_dir.exists():
    # Prefer production build in dist over static
    dist_assets = ui_dist_dir / 'assets'
    if dist_assets.exists():
        app.mount('/haven-ui/assets', StaticFiles(directory=str(dist_assets)), name='ui-dist-assets')
    # Mount dist root at /haven-ui (production build)
    app.mount('/haven-ui', StaticFiles(directory=str(ui_dist_dir), html=True), name='ui-dist')
    # Also mount raw dist path so /haven-ui/dist/* works
    app.mount('/haven-ui/dist', StaticFiles(directory=str(ui_dist_dir)), name='ui-dist-dir')
    # Also make map-specific static paths available at '/map/static' so /map/latest loads correctly
    map_static_dir = ui_dist_dir / 'static'
    if map_static_dir.exists():
        app.mount('/map/static', StaticFiles(directory=str(map_static_dir)), name='map-static')
    map_assets_dir = ui_dist_dir / 'assets'
    if map_assets_dir.exists():
        app.mount('/map/assets', StaticFiles(directory=str(map_assets_dir)), name='map-assets')
    # Provide fallback static under a different path
    if ui_static_dir.exists():
        app.mount('/haven-ui-static', StaticFiles(directory=str(ui_static_dir)), name='haven-ui-static')
else:
    if ui_static_dir.exists():
        # Mount assets FIRST before the catch-all html=True mount
        assets_dir = ui_static_dir / 'assets'
        if assets_dir.exists():
            app.mount('/haven-ui/assets', StaticFiles(directory=str(assets_dir)), name='ui-static-assets')
        # Now mount the main UI with html=True (this catches remaining requests)
        app.mount('/haven-ui', StaticFiles(directory=str(ui_static_dir), html=True), name='ui-static')
        app.mount('/haven-ui-static', StaticFiles(directory=str(ui_static_dir)), name='haven-ui-static')

# In-memory system cache
_systems_cache: Dict[str, dict] = {}
_systems_lock = asyncio.Lock()

def load_data_json() -> dict:
    if not DATA_JSON.exists():
        return {'systems': []}
    try:
        return json.loads(DATA_JSON.read_text(encoding='utf-8'))
    except Exception as e:
        logger.error('Failed loading data.json: %s', e)
        return {'systems': []}

def save_data_json(data: dict):
    DATA_JSON.write_text(json.dumps(data, indent=2), encoding='utf-8')


def get_db_path() -> Path:
    return HAVEN_UI_DIR / 'data' / 'haven_ui.db'


def get_db_connection():
    """Create a properly configured database connection with timeout and WAL mode.

    This ensures all connections use consistent settings to avoid database locks.
    """
    db_path = get_db_path()
    conn = sqlite3.connect(str(db_path), timeout=30.0)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA busy_timeout=30000')
    conn.row_factory = sqlite3.Row
    return conn


@contextmanager
def get_db():
    """Context manager for database connections - ensures proper cleanup even on exceptions."""
    conn = None
    try:
        conn = get_db_connection()
        yield conn
    finally:
        if conn:
            conn.close()


def init_database():
    """Initialize the Haven database with required tables."""
    db_path = get_db_path()

    # Check if database might be corrupted and restore from backup if needed
    try:
        # Try to open and do a simple integrity check
        test_conn = sqlite3.connect(str(db_path), timeout=30.0)
        test_conn.execute('PRAGMA integrity_check')
        test_conn.close()
    except Exception as e:
        logger.exception('Database integrity check failed: %s', e)
        # Try to restore from backup
        backup_path = db_path.parent / 'haven_ui.db.backup'
        if backup_path.exists():
            logger.warning('Attempting to restore from backup: %s', backup_path)
            import shutil
            # Move corrupted database aside and restore from backup (best-effort)
            corrupted_path = db_path.parent / 'haven_ui.db.corrupted'
            try:
                if db_path.exists():
                    shutil.move(str(db_path), str(corrupted_path))
                    logger.info('Moved corrupted DB to %s', corrupted_path)
                # Restore from backup
                shutil.copy2(str(backup_path), str(db_path))
                logger.info('Database restored from backup')
            except Exception as ex:
                logger.exception('Failed to restore database from backup: %s', ex)
                # If restore fails we'll continue and allow the table creation below
                # to create a fresh database; don't raise here so startup can continue.
        else:
            logger.info('No backup available, will create a fresh database')

    conn = sqlite3.connect(str(db_path), timeout=30.0)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA busy_timeout=30000')
    cursor = conn.cursor()

    # Create discoveries table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS discoveries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            discovery_type TEXT,
            discovery_name TEXT,
            system_id INTEGER,
            planet_id INTEGER,
            moon_id INTEGER,
            location_type TEXT,
            location_name TEXT,
            description TEXT,
            significance TEXT DEFAULT 'Notable',
            discovered_by TEXT DEFAULT 'anonymous',
            submission_timestamp TEXT,
            mystery_tier INTEGER DEFAULT 1,
            analysis_status TEXT DEFAULT 'pending',
            pattern_matches INTEGER DEFAULT 0,
            discord_user_id TEXT,
            discord_guild_id TEXT,
            photo_url TEXT,
            evidence_url TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Create pending_systems table for approval queue
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS pending_systems (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            submitted_by TEXT,
            submitted_by_ip TEXT,
            submission_date TEXT,
            system_data TEXT,
            status TEXT DEFAULT 'pending',
            system_name TEXT,
            system_region TEXT,
            reviewed_by TEXT,
            review_date TEXT,
            review_notes TEXT
        )
    ''')

    conn.commit()
    conn.close()
    logger.info(f"Database initialized at {db_path}")


# NOTE: database initialization is now performed at application startup
# to avoid raising exceptions during module import (which breaks
# `python server.py` and other importers). This makes startup failures
# visible in logs and keeps import-time behavior safe for supervisors.


def _row_to_dict(row):
    if row is None:
        return None
    return {k: row[k] for k in row.keys()}


def load_systems_from_db() -> list:
    """Load systems from haven_ui.db and return nested structure (planets & moons).

    Falls back to empty list if DB does not exist or tables are missing.
    """
    db_path = get_db_path()
    if not db_path.exists():
        return []
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Read all systems
        cursor.execute('SELECT * FROM systems')
        systems_rows = cursor.fetchall()
        systems = [dict(row) for row in systems_rows]

        # Read planets and moons and nest them
        cursor.execute('SELECT * FROM planets')
        planets_rows = cursor.fetchall()
        planets = [dict(p) for p in planets_rows]

        cursor.execute('SELECT * FROM moons')
        moons_rows = cursor.fetchall()
        moons = [dict(m) for m in moons_rows]

        # Index planets by system_id
        planets_by_system = {}
        for p in planets:
            planets_by_system.setdefault(p.get('system_id'), []).append(p)

        # Index moons by planet_id
        moons_by_planet = {}
        for m in moons:
            moons_by_planet.setdefault(m.get('planet_id'), []).append(m)

        # Build nested structure
        for s in systems:
            sys_id = s.get('id')
            sys_planets = planets_by_system.get(sys_id, [])
            for p in sys_planets:
                p['moons'] = moons_by_planet.get(p.get('id'), [])
            s['planets'] = sys_planets

        return systems
    except Exception as e:
        logger.error('Failed to read systems from DB: %s', e)
        return []
    finally:
        if conn:
            conn.close()


def query_discoveries_from_db(q: str = '', system_id: str = None, planet_id: int = None, moon_id: int = None) -> list:
    """Return list of discoveries from DB, optionally filtering by query across fields."""
    db_path = get_db_path()
    if not db_path.exists():
        return []
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        where_clauses = []
        params = []
        if q:
            q_pattern = f"%{q}%"
            where_clauses.append("(discovery_name LIKE ? OR description LIKE ? OR location_name LIKE ?)")
            params.extend([q_pattern, q_pattern, q_pattern])
        if system_id:
            where_clauses.append("system_id = ?")
            params.append(system_id)
        if planet_id:
            where_clauses.append("planet_id = ?")
            params.append(planet_id)
        if moon_id:
            where_clauses.append("moon_id = ?")
            params.append(moon_id)
        base_query = "SELECT * FROM discoveries"
        if where_clauses:
            base_query += " WHERE " + " AND ".join(where_clauses)
        base_query += " ORDER BY submission_timestamp DESC LIMIT 250"
        cursor.execute(base_query, params)
        rows = cursor.fetchall()
        discoveries = [dict(r) for r in rows]
        return discoveries
    except Exception as e:
        logger.error('Failed to query discoveries from DB: %s', e)
        return []
    finally:
        if conn:
            conn.close()

@app.on_event('startup')
async def on_startup():
    # Initialize DB on startup so import-time failures are avoided.
    try:
        init_database()
    except Exception as e:
        # Log the error but continue — we'll still attempt to load systems
        logger.exception('Database initialization failed during startup: %s', e)
    # Load systems from DB if available, otherwise fallback to data.json
    systems = []
    try:
        db_path = get_db_path()
        if db_path.exists():
            systems = load_systems_from_db()
        else:
            data = load_data_json()
            systems = data.get('systems', [])
    except Exception:
        data = load_data_json()
        systems = data.get('systems', [])
    async with _systems_lock:
        _systems_cache.clear()
        for s in systems:
            _systems_cache[s.get('name')] = s
    logger.info('Control Room API started with %d systems', len(_systems_cache))

@app.get('/')
async def root():
    """Redirect root to Haven UI"""
    return RedirectResponse(url='/haven-ui/')

@app.get('/favicon.ico')
async def favicon():
    """Serve favicon from dist or return 204"""
    from fastapi.responses import FileResponse, Response
    favicon_svg = HAVEN_UI_DIR / 'dist' / 'favicon.svg'
    if favicon_svg.exists():
        return FileResponse(str(favicon_svg), media_type='image/svg+xml')
    return Response(status_code=204)

@app.get('/haven-ui/favicon.ico')
async def favicon_haven():
    """Serve favicon from dist"""
    from fastapi.responses import FileResponse, Response
    favicon_svg = HAVEN_UI_DIR / 'dist' / 'favicon.svg'
    if favicon_svg.exists():
        return FileResponse(str(favicon_svg), media_type='image/svg+xml')
    return Response(status_code=204)

@app.get('/haven-ui/icon.svg')
async def icon_svg():
    """Serve icon.svg from dist"""
    from fastapi.responses import FileResponse, Response
    icon = HAVEN_UI_DIR / 'dist' / 'icon.svg'
    if icon.exists():
        return FileResponse(str(icon), media_type='image/svg+xml')
    return Response(status_code=204)

@app.get('/workbox-{version}.js')
async def workbox(version: str):
    """Return 204 No Content for missing workbox (prevents 404 errors)"""
    from fastapi.responses import Response
    return Response(status_code=204)


@app.get('/haven-ui/workbox-{version}.js')
async def workbox_haven(version: str):
    from fastapi.responses import FileResponse, Response
    # Try to serve from dist, otherwise return 204
    dist_path = HAVEN_UI_DIR / 'dist' / f'workbox-{version}.js'
    if dist_path.exists():
        return FileResponse(str(dist_path))
    return Response(status_code=204)


@app.get('/haven-ui/sw.js')
async def sw_js():
    from fastapi.responses import FileResponse, Response
    dist_path = HAVEN_UI_DIR / 'dist' / 'sw.js'
    if dist_path.exists():
        return FileResponse(str(dist_path))
    # fallback to static sw.js if it exists
    static_sw = HAVEN_UI_DIR / 'static' / 'sw.js'
    if static_sw.exists():
        return FileResponse(str(static_sw))
    return Response(status_code=204)


@app.get('/haven-ui/registerSW.js')
async def register_sw():
    from fastapi.responses import FileResponse, Response
    dist_path = HAVEN_UI_DIR / 'dist' / 'registerSW.js'
    if dist_path.exists():
        return FileResponse(str(dist_path))
    static_path = HAVEN_UI_DIR / 'static' / 'registerSW.js'
    if static_path.exists():
        return FileResponse(str(static_path))
    return Response(status_code=204)

@app.get('/api/status')
async def api_status():
    return {'status': 'ok', 'version': 'minimal-api'}

@app.get('/api/stats')
async def api_stats():
    async with _systems_lock:
        systems = list(_systems_cache.values())
    galaxies = sorted(list({s.get('galaxy') for s in systems if s.get('galaxy')}))
    return {'total': len(systems), 'galaxies': galaxies}

# Glyph operations
@app.post('/api/decode_glyph')
async def api_decode_glyph(payload: dict):
    """
    Decode a portal glyph to coordinates.

    Request: {"glyph": "10A4F3E7B2C1", "apply_scale": true}
    Response: {"x": -1343, "y": 115, "z": 1659, "planet": 1, ...}
    """
    glyph = payload.get('glyph', '').strip().upper()
    apply_scale = payload.get('apply_scale', False)

    if not glyph:
        raise HTTPException(status_code=400, detail="Missing glyph code")

    is_valid, error = validate_glyph_code(glyph)
    if not is_valid:
        raise HTTPException(status_code=400, detail=error)

    try:
        result = decode_glyph_to_coords(glyph, apply_scale=apply_scale)
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post('/api/encode_glyph')
async def api_encode_glyph(payload: dict):
    """
    Encode coordinates to a portal glyph.

    Request: {"x": 500, "y": -50, "z": -1200, "planet": 0, "solar_system": 1}
    Response: {"glyph": "0-001-4E-350-9F4", "glyph_raw": "00014E3509F4"}
    """
    try:
        x = int(payload.get('x', 0))
        y = int(payload.get('y', 0))
        z = int(payload.get('z', 0))
        planet = int(payload.get('planet', 0))
        solar_system = int(payload.get('solar_system', 1))

        glyph = encode_coords_to_glyph(x, y, z, planet, solar_system)
        return {
            'glyph': format_glyph(glyph),
            'glyph_raw': glyph
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get('/api/glyph_images')
async def api_glyph_images():
    """
    Get mapping of hex digits to glyph image filenames.

    Response: {"0": "IMG_9202.jpg", "1": "IMG_9203.jpg", ...}
    """
    return GLYPH_IMAGES


@app.post('/api/validate_glyph')
async def api_validate_glyph(payload: dict):
    """
    Validate a glyph code without decoding.

    Request: {"glyph": "10A4F3E7B2C1"}
    Response: {"valid": true, "warning": null} or {"valid": false, "error": "..."}
    """
    glyph = payload.get('glyph', '').strip().upper()

    if not glyph:
        return {'valid': False, 'error': 'Missing glyph code'}

    is_valid, message = validate_glyph_code(glyph)

    if is_valid and message:
        # Has warnings
        return {'valid': True, 'warning': message}
    elif is_valid:
        return {'valid': True, 'warning': None}
    else:
        return {'valid': False, 'error': message}

# Settings storage (simple JSON-based)
_settings_cache = {}

@app.get('/api/settings')
async def get_settings():
    """Get current settings (theme, etc.)"""
    return _settings_cache

@app.post('/api/settings')
async def save_settings(settings: dict):
    """Save settings"""
    _settings_cache.update(settings)
    return {'status': 'ok'}

# Admin authentication (session-based with cookies)
from fastapi import Response, Cookie
from typing import Optional
import secrets

ADMIN_PASSWORD = os.getenv('HAVEN_ADMIN_PASSWORD', 'Haven')
_admin_sessions = {}  # session_token -> expiry_time

def generate_session_token() -> str:
    """Generate a secure random session token"""
    return secrets.token_urlsafe(32)

def verify_session(session_token: Optional[str]) -> bool:
    """Check if session token is valid"""
    if not session_token:
        return False
    return session_token in _admin_sessions

@app.get('/api/admin/status')
async def admin_status(session: Optional[str] = Cookie(None)):
    """Check if admin is logged in"""
    logged_in = verify_session(session)
    return {'logged_in': logged_in}

@app.post('/api/admin/login')
async def admin_login(credentials: dict, response: Response):
    """Admin login - sets secure session cookie"""
    password = credentials.get('password', '')
    if password == ADMIN_PASSWORD:
        # Create session token
        session_token = generate_session_token()
        _admin_sessions[session_token] = True

        # Set secure HTTP-only cookie
        response.set_cookie(
            key='session',
            value=session_token,
            httponly=True,
            max_age=86400,  # 24 hours
            samesite='lax'
        )
        return {'status': 'ok', 'logged_in': True}
    raise HTTPException(status_code=401, detail='Invalid password')

@app.post('/api/admin/logout')
async def admin_logout(response: Response, session: Optional[str] = Cookie(None)):
    """Admin logout - clears session"""
    if session and session in _admin_sessions:
        del _admin_sessions[session]
    response.delete_cookie('session')
    return {'status': 'ok'}

@app.get('/api/systems')
async def api_systems():
    # If DB is available, return current systems by querying DB; otherwise return JSON cache
    try:
        db_path = get_db_path()
        if db_path.exists():
            systems = load_systems_from_db()
            return {'systems': systems}
    except Exception:
        pass
    async with _systems_lock:
        systems = list(_systems_cache.values())
    return {'systems': systems}


@app.get('/api/systems/{system_id}')
async def get_system(system_id: str):
    """Return a single system by id or name, including nested planets and moons."""
    conn = None
    try:
        db_path = get_db_path()
        if db_path.exists():
            conn = get_db_connection()
            cursor = conn.cursor()
            # Try by id
            cursor.execute('SELECT * FROM systems WHERE id = ?', (system_id,))
            row = cursor.fetchone()
            if not row:
                # Try by name
                cursor.execute('SELECT * FROM systems WHERE name = ?', (system_id,))
                row = cursor.fetchone()
            if not row:
                raise HTTPException(status_code=404, detail='System not found')
            system = dict(row)
            # planets
            cursor.execute('SELECT * FROM planets WHERE system_id = ?', (system.get('id'),))
            planets_rows = cursor.fetchall()
            planets = [dict(p) for p in planets_rows]
            for p in planets:
                cursor.execute('SELECT * FROM moons WHERE planet_id = ?', (p.get('id'),))
                moons_rows = cursor.fetchall()
                p['moons'] = [dict(m) for m in moons_rows]
            system['planets'] = planets
            return system

        # JSON fallback
        data = load_data_json()
        systems = data.get('systems', [])
        for s in systems:
            if s.get('id') == system_id or s.get('name') == system_id:
                return s
        raise HTTPException(status_code=404, detail='System not found')
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if conn:
            conn.close()


@app.delete('/api/systems/{system_id}')
async def delete_system(system_id: str):
    conn = None
    try:
        db_path = get_db_path()
        if db_path.exists():
            conn = get_db_connection()
            cursor = conn.cursor()
            # Try delete by id first then by name
            cursor.execute('DELETE FROM discoveries WHERE system_id = ?', (system_id,))
            # Delete planets and moons
            cursor.execute('SELECT id FROM planets WHERE system_id = ?', (system_id,))
            planet_rows = cursor.fetchall()
            planet_ids = [r[0] for r in planet_rows]
            if planet_ids:
                cursor.executemany('DELETE FROM moons WHERE planet_id = ?', [(pid,) for pid in planet_ids])
                cursor.execute('DELETE FROM planets WHERE system_id = ?', (system_id,))
            # Delete system by id first
            cursor.execute('DELETE FROM systems WHERE id = ?', (system_id,))
            # If nothing deleted, try by name
            if conn.total_changes == 0:
                cursor.execute('SELECT id FROM systems WHERE name = ?', (system_id,))
                row = cursor.fetchone()
                if row:
                    sid = row[0]
                    cursor.execute('DELETE FROM discoveries WHERE system_id = ?', (sid,))
                    cursor.execute('SELECT id FROM planets WHERE system_id = ?', (sid,))
                    pr = cursor.fetchall()
                    pids = [r[0] for r in pr]
                    if pids:
                        cursor.executemany('DELETE FROM moons WHERE planet_id = ?', [(pid,) for pid in pids])
                        cursor.execute('DELETE FROM planets WHERE system_id = ?', (sid,))
                    cursor.execute('DELETE FROM systems WHERE id = ?', (sid,))
            conn.commit()
            return {'status': 'ok'}

        # Fallback to JSON
        data = load_data_json()
        systems = data.get('systems', [])
        new_systems = [s for s in systems if not (s.get('id') == system_id or s.get('name') == system_id)]
        if len(new_systems) == len(systems):
            raise HTTPException(status_code=404, detail='System not found')
        data['systems'] = new_systems
        save_data_json(data)
        async with _systems_lock:
            _systems_cache.clear()
            for s in new_systems:
                _systems_cache[s.get('name')] = s
        return {'status': 'ok'}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if conn:
            conn.close()


# ---- Legacy endpoints (compatibility with older integrations like Keeper) ----
@app.get('/systems')
async def legacy_systems():
    return await api_systems()

@app.get('/systems/search')
async def legacy_systems_search(q: str = ''):
    return await api_search(q)


@app.get('/api/systems/search')
async def api_search(q: str = ''):
    q = q.strip().lower()
    # Prefer DB search
    try:
        db_path = get_db_path()
        if db_path.exists():
            systems = load_systems_from_db()
            if not q:
                return {'results': systems}
            res = [s for s in systems if q in s.get('name', '').lower()]
            return {'results': res}
    except Exception:
        pass
    async with _systems_lock:
        systems = list(_systems_cache.values())
    if not q:
        return {'results': systems}
    res = [s for s in systems if q in s.get('name', '').lower()]
    return {'results': res}

@app.post('/api/save_system')
async def save_system(payload: dict, session: Optional[str] = Cookie(None)):
    """
    Save a system directly to the database (admin only).
    Non-admin users should use /api/submit_system instead.
    """
    # Verify admin session
    if not verify_session(session):
        raise HTTPException(
            status_code=401,
            detail='Admin authentication required. Non-admin users should submit systems for approval.'
        )

    name = payload.get('name')
    if not name:
        raise HTTPException(status_code=400, detail='Name required')
    async with _systems_lock:
        _systems_cache[name] = payload
        save_data_json({'systems': list(_systems_cache.values())})
    return {'status': 'ok', 'saved': payload}

@app.get('/api/db_stats')
async def db_stats():
    """Get database statistics"""
    conn = None
    try:
        db_path = HAVEN_UI_DIR / 'data' / 'haven_ui.db'
        if not db_path.exists():
            return {'stats': {}, 'note': 'Database not found'}

        conn = get_db_connection()
        cursor = conn.cursor()

        stats = {}
        # Get table counts
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]

        for table in tables:
            try:
                cursor.execute(f"SELECT COUNT(*) FROM {table}")
                count = cursor.fetchone()[0]
                stats[table] = count
            except:
                pass

        return {'stats': stats}
    except Exception as e:
        logger.error(f'Error getting db_stats: {e}')
        return {'stats': {}, 'error': str(e)}
    finally:
        if conn:
            conn.close()

@app.post('/api/generate_map')
async def generate_map():
    """Trigger map generation (queued for background processing)"""
    # This would normally trigger a background task
    # For now, just return success
    return {'status': 'ok', 'message': 'Map generation queued'}

@app.get('/api/tests')
async def list_tests():
    """List available test files"""
    try:
        tests_dir = HAVEN_UI_DIR.parent / 'tests'
        if not tests_dir.exists():
            return {'tests': []}

        test_files = []
        for file in tests_dir.glob('**/*.py'):
            if file.name.startswith('test_'):
                test_files.append(str(file.relative_to(HAVEN_UI_DIR.parent)))

        return {'tests': test_files}
    except Exception as e:
        return {'tests': [], 'error': str(e)}

@app.post('/api/tests/run')
async def run_test(payload: dict):
    """Run a specific test"""
    import subprocess
    test_path = payload.get('test_path', '')
    if not test_path:
        raise HTTPException(status_code=400, detail='test_path required')

    try:
        result = subprocess.run(
            ['python', '-m', 'pytest', test_path, '-v'],
            capture_output=True,
            text=True,
            timeout=30
        )
        return {
            'returncode': result.returncode,
            'stdout': result.stdout,
            'stderr': result.stderr
        }
    except subprocess.TimeoutExpired:
        return {'returncode': -1, 'stdout': '', 'stderr': 'Test timed out'}
    except Exception as e:
        return {'returncode': -1, 'stdout': '', 'stderr': str(e)}

@app.post('/api/photos')
async def upload_photo(file: UploadFile = File(...)):
    filename = file.filename or 'photo'
    dest = PHOTOS_DIR / filename
    # avoid overwriting by renaming
    if dest.exists():
        base = dest.stem
        suffix = dest.suffix
        i = 1
        while (PHOTOS_DIR / f"{base}-{i}{suffix}").exists():
            i += 1
        dest = PHOTOS_DIR / f"{base}-{i}{suffix}"
    with dest.open('wb') as f:
        f.write(await file.read())
    path = str(dest.relative_to(HAVEN_UI_DIR))
    return JSONResponse({'path': path})

@app.get('/map/latest')
async def get_map():
    # Serve the Three.js-based map with live DB data injection
    mapfile = HAVEN_UI_DIR / 'dist' / 'VH-Map-ThreeJS.html'

    # Fallback to old map if ThreeJS version doesn't exist
    if not mapfile.exists():
        mapfile = HAVEN_UI_DIR / 'dist' / 'VH-Map.html'

    if not mapfile.exists():
        return HTMLResponse('<h1>Map Not Available</h1>')

    try:
        html = mapfile.read_text(encoding='utf-8')
        # Load systems and discoveries from DB when present
        db_path = get_db_path()
        if db_path.exists():
            systems = load_systems_from_db()
            discoveries = query_discoveries_from_db()
            systems_json = json.dumps(systems, ensure_ascii=False)
            discoveries_json = json.dumps(discoveries, ensure_ascii=False)
            # Replace embedded arrays - escape backslashes for regex replacement
            systems_replacement = systems_json.replace('\\', '\\\\')
            discoveries_replacement = discoveries_json.replace('\\', '\\\\')
            html = re.sub(r"window\.SYSTEMS_DATA\s*=\s*\[.*?\];", f"window.SYSTEMS_DATA = {systems_replacement};", html, flags=re.S)
            html = re.sub(r"window\.DISCOVERIES_DATA\s*=\s*\[.*?\];", f"window.DISCOVERIES_DATA = {discoveries_replacement};", html, flags=re.S)
        return HTMLResponse(html, media_type='text/html')
    except Exception as e:
        logger.error('Failed to render map latest: %s', e)
        return HTMLResponse('<h1>Map Error</h1>')


@app.get('/haven-ui/VH-Map.html')
async def get_haven_ui_map():
    # Mirror /map/latest behavior for the UI-hosted map page
    return await get_map()


@app.get('/map/VH-Map.html')
async def redirect_map_vh():
    return RedirectResponse(url='/map/latest')


@app.get('/haven-ui/map')
async def redirect_haven_ui_map():
    return RedirectResponse(url='/map/latest')


@app.get('/map/{page}')
async def serve_map_page(page: str):
    """Serve map pages under /map/ including system pages and assets.

    - /map/latest -> handled elsewhere
    - /map/system_<name>.html -> serve system HTML from dist with injected DB data
    - static files under /map/* are handled by the mount '/map/static' and '/map/assets'
    """
    # served by dedicated dynamic handler
    if page == 'latest':
        return await get_map()

    # handle system pages like system_AURORA-7.html
    if page.startswith('system_') and page.endswith('.html'):
        filepath = HAVEN_UI_DIR / 'dist' / page
        if not filepath.exists():
            # Try case-insensitive fallback
            found = None
            for f in (HAVEN_UI_DIR / 'dist').glob('system_*.html'):
                if f.name.lower() == page.lower():
                    found = f
                    break
            if not found:
                raise HTTPException(status_code=404, detail='System page not found')
            filepath = found
        try:
            html = filepath.read_text(encoding='utf-8', errors='ignore')
            # Parse system name from the static page's SYSTEM_META if present
            m = re.search(r"window\.SYSTEM_META\s*=\s*(\{.*?\});", html, flags=re.S)
            system_name = None
            if m:
                try:
                    meta = json.loads(m.group(1))
                    system_name = meta.get('name')
                except Exception:
                    system_name = None

            # If not found via meta, derive from filename
            if not system_name:
                # strip prefix and suffix
                system_name = page[len('system_'):-len('.html')]
                # Replace underscores with spaces where appropriate
                system_name = system_name.replace('_', ' ')

            # Now find system in DB by name or id
            systems = load_systems_from_db()
            system = None
            for s in systems:
                if s.get('name') == system_name or s.get('id') == system_name or (s.get('name') or '').lower() == (system_name or '').lower():
                    system = s
                    break

            if system:
                planets = system.get('planets', [])
                discoveries = query_discoveries_from_db(system_id=system.get('id'))

                # Load space stations for this system
                db_path = get_db_path()
                space_stations = []
                if db_path.exists():
                    conn = None
                    try:
                        conn = get_db_connection()
                        cursor = conn.cursor()
                        cursor.execute('SELECT * FROM space_stations WHERE system_id = ?', (system.get('id'),))
                        stations_rows = cursor.fetchall()
                        space_stations = [dict(row) for row in stations_rows]
                        logger.info(f"Loaded {len(space_stations)} space stations for system {system.get('name')}")
                    except Exception as e:
                        logger.warning(f"Could not load space stations: {e}")
                    finally:
                        if conn:
                            conn.close()

                # Combine planets and stations into SYSTEMS_DATA
                # Add type field to stations for proper rendering
                systems_data = planets.copy()
                for station in space_stations:
                    station['type'] = 'station'  # Critical: tells map-viewer.js to render as purple box
                    systems_data.append(station)

                system_meta = {
                    'name': system.get('name'),
                    'galaxy': system.get('galaxy'),
                    'glyph': system.get('glyph_code'),
                    'x': system.get('x'),
                    'y': system.get('y'),
                    'z': system.get('z')
                }
                # Replace JSON data in HTML
                html = re.sub(r"window\.SYSTEMS_DATA\s*=\s*\[.*?\];", f"window.SYSTEMS_DATA = {json.dumps(systems_data)};", html, flags=re.S)
                html = re.sub(r"window\.SYSTEM_META\s*=\s*\{.*?\};", f"window.SYSTEM_META = {json.dumps(system_meta)};", html, flags=re.S)
                html = re.sub(r"window\.DISCOVERIES_DATA\s*=\s*\[.*?\];", f"window.DISCOVERIES_DATA = {json.dumps(discoveries)};", html, flags=re.S)
            return HTMLResponse(html, media_type='text/html')
        except Exception as e:
            logger.error('Failed to render system page %s: %s', page, e)
            raise HTTPException(status_code=500, detail='Error rendering system page')

    # Not a special map page - 404
    raise HTTPException(status_code=404, detail='Not found')


@app.get('/map/system/{system_id}')
async def get_system_3d_view(system_id: str):
    """Serve the 3D planetary view for a specific system with injected DB data.

    This serves VH-System-View.html with system data (planets, moons, station, discoveries)
    injected into window.SYSTEM_DATA.
    """
    # Find the system view HTML file
    system_view_file = HAVEN_UI_DIR / 'dist' / 'VH-System-View.html'

    if not system_view_file.exists():
        # Fallback to public directory
        system_view_file = HAVEN_UI_DIR / 'public' / 'VH-System-View.html'

    if not system_view_file.exists():
        raise HTTPException(status_code=404, detail='System view page not found')

    conn = None
    try:
        html = system_view_file.read_text(encoding='utf-8')

        # Load system data from database
        db_path = get_db_path()
        if not db_path.exists():
            raise HTTPException(status_code=500, detail='Database not found')

        conn = get_db_connection()
        cursor = conn.cursor()

        # Try to find system by id first, then by name
        cursor.execute('SELECT * FROM systems WHERE id = ?', (system_id,))
        row = cursor.fetchone()
        if not row:
            cursor.execute('SELECT * FROM systems WHERE name = ?', (system_id,))
            row = cursor.fetchone()

        if not row:
            raise HTTPException(status_code=404, detail='System not found')

        system = dict(row)
        sys_id = system.get('id')

        # Load planets with their moons
        cursor.execute('SELECT * FROM planets WHERE system_id = ?', (sys_id,))
        planets_rows = cursor.fetchall()
        planets = []

        for p_row in planets_rows:
            planet = dict(p_row)
            planet_id = planet.get('id')

            # Load moons for this planet
            cursor.execute('SELECT * FROM moons WHERE planet_id = ?', (planet_id,))
            moons_rows = cursor.fetchall()
            planet['moons'] = [dict(m) for m in moons_rows]

            # Load discoveries for planet
            cursor.execute('SELECT * FROM discoveries WHERE planet_id = ?', (planet_id,))
            disc_rows = cursor.fetchall()
            planet['discoveries'] = [dict(d) for d in disc_rows]

            # Load discoveries for moons
            for moon in planet['moons']:
                moon_id = moon.get('id')
                # Check both moon_id column and planet_id column (for legacy data)
                cursor.execute('SELECT * FROM discoveries WHERE moon_id = ? OR planet_id = ?', (moon_id, moon_id))
                moon_disc_rows = cursor.fetchall()
                moon['discoveries'] = [dict(d) for d in moon_disc_rows]

            planets.append(planet)

        system['planets'] = planets

        # Load space station
        cursor.execute('SELECT * FROM space_stations WHERE system_id = ?', (sys_id,))
        station_row = cursor.fetchone()
        if station_row:
            system['space_station'] = dict(station_row)
        else:
            system['space_station'] = None

        # Inject system data into HTML
        system_json = json.dumps(system)
        html = re.sub(
            r"window\.SYSTEM_DATA\s*=\s*null;",
            f"window.SYSTEM_DATA = {system_json};",
            html
        )

        return HTMLResponse(html, media_type='text/html')

    except HTTPException:
        raise
    except Exception as e:
        logger.error('Failed to render system 3D view for %s: %s', system_id, e)
        raise HTTPException(status_code=500, detail=f'Error rendering system view: {str(e)}')
    finally:
        if conn:
            conn.close()


# Simple logs API
@app.get('/api/logs')
async def get_logs():
    logfile = LOGS_DIR / 'control-room-web.log'
    if not logfile.exists():
        return {'lines': []}
    lines = logfile.read_text(encoding='utf-8', errors='ignore').splitlines()[-200:]
    return {'lines': lines}

# Minimal RT-AI integration: import and initialize if available
try:
    from roundtable_ai.api_integration import get_round_table_ai
    HAVE_RTAI = True
    rtai_instance = None
except Exception:
    HAVE_RTAI = False
    rtai_instance = None

@app.get('/api/rtai/status')
async def rtai_status():
    if not HAVE_RTAI:
        return {'available': False}
    if rtai_instance is None:
        return {'available': False}
    return {'available': True, 'agents': rtai_instance.list_agents(), 'stats': rtai_instance.get_statistics()}

@app.post('/api/rtai/analyze/discoveries')
async def analyze_discoveries(limit: int = 10):
    if not HAVE_RTAI or rtai_instance is None:
        raise HTTPException(status_code=503, detail='RTAI not available')
    result = await rtai_instance.analyze_discoveries(limit=limit)
    return {'result': result}

# RT-AI chat history (simple in-memory storage)
_rtai_history = []

@app.get('/api/rtai/history')
async def rtai_history():
    """Get RT-AI chat history"""
    return {'messages': _rtai_history}

@app.post('/api/rtai/clear')
async def rtai_clear():
    """Clear RT-AI chat history"""
    _rtai_history.clear()
    return {'status': 'ok'}

@app.post('/api/backup')
async def create_backup():
    """Create database backup"""
    try:
        import shutil
        from datetime import datetime
        db_path = HAVEN_UI_DIR / 'data' / 'haven_ui.db'
        if not db_path.exists():
            raise HTTPException(status_code=404, detail='Database not found')

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path = HAVEN_UI_DIR / 'data' / f'haven_ui_backup_{timestamp}.db'
        shutil.copy2(db_path, backup_path)

        return {'backup_path': str(backup_path.relative_to(HAVEN_UI_DIR))}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post('/api/db_upload')
async def db_upload(file: UploadFile = File(...)):
    """Upload a database file"""
    try:
        dest = HAVEN_UI_DIR / 'data' / 'uploaded.db'
        with open(dest, 'wb') as f:
            content = await file.read()
            f.write(content)
        return {'path': str(dest.relative_to(HAVEN_UI_DIR))}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Lightweight endpoint for the Keeper bot to post discoveries
@app.get('/api/discoveries')
async def get_discoveries(q: str = '', user_id: str = '', limit: int = 100):
    """List or search discoveries, optionally filtered by user_id"""
    conn = None
    try:
        db_path = get_db_path()
        if db_path.exists():
            # If user_id provided, filter by discord_user_id
            if user_id:
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT d.*, s.name as system_name
                    FROM discoveries d
                    LEFT JOIN systems s ON d.system_id = s.id
                    WHERE d.discord_user_id = ?
                    ORDER BY d.submission_timestamp DESC
                    LIMIT ?
                ''', (user_id, limit))
                discoveries = [dict(row) for row in cursor.fetchall()]
                return {'discoveries': discoveries}

            discoveries = query_discoveries_from_db(q=q)
            return {'results': discoveries}

        data = load_data_json()
        discoveries = data.get('discoveries', [])
        # Filter by search query if provided
        if q:
            q_lower = q.lower()
            discoveries = [
                d for d in discoveries
                if (q_lower in str(d.get('description', '')).lower() or
                    q_lower in str(d.get('discovery_name', '')).lower() or
                    q_lower in str(d.get('location_name', '')).lower())
            ]
        # Filter by user_id if provided
        if user_id:
            discoveries = [d for d in discoveries if str(d.get('discord_user_id', '')) == user_id]
            discoveries = discoveries[:limit]
        return {'results': discoveries}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if conn:
            conn.close()

@app.get('/api/discoveries/{discovery_id}')
async def get_discovery(discovery_id: int):
    """Get a specific discovery by ID"""
    conn = None
    try:
        db_path = get_db_path()
        if db_path.exists():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM discoveries WHERE id = ?', (discovery_id,))
            row = cursor.fetchone()
            if not row:
                raise HTTPException(status_code=404, detail='Discovery not found')
            return dict(row)

        data = load_data_json()
        discoveries = data.get('discoveries', [])

        if discovery_id < 1 or discovery_id > len(discoveries):
            raise HTTPException(status_code=404, detail='Discovery not found')

        return discoveries[discovery_id - 1]
    except HTTPException:
        raise
    except IndexError:
        raise HTTPException(status_code=404, detail='Discovery not found')
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if conn:
            conn.close()

@app.post('/api/discoveries')
async def create_discovery(payload: dict):
    """Accept a discovery submission and store in the database."""
    conn = None
    try:
        db_path = get_db_path()
        logger.info(f"Received discovery submission: {payload.get('discovery_type', 'unknown')} from {payload.get('discovered_by', 'anonymous')}")

        # Always use database (initialized on startup)
        # Use standardized connection settings to avoid database locks
        conn = get_db_connection()
        cursor = conn.cursor()

        # Get submission timestamp
        submission_ts = payload.get('submission_timestamp') or datetime.now().isoformat()

        cursor.execute('''
            INSERT INTO discoveries (
                discovery_type, discovery_name, system_id, planet_id, moon_id, location_type, location_name, description, significance, discovered_by, submission_timestamp, mystery_tier, analysis_status, pattern_matches, discord_user_id, discord_guild_id, photo_url
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            payload.get('discovery_type') or 'Unknown',
            payload.get('discovery_name') or 'Unnamed Discovery',
            payload.get('system_id'),
            payload.get('planet_id'),
            payload.get('moon_id'),
            payload.get('location_type') or 'space',
            payload.get('location_name') or 'Unknown Location',
            payload.get('description') or '',
            payload.get('significance') or 'Notable',
            payload.get('discovered_by') or 'anonymous',
            submission_ts,
            payload.get('mystery_tier') or 1,
            payload.get('analysis_status') or 'pending',
            payload.get('pattern_matches') or 0,
            payload.get('discord_user_id'),
            payload.get('discord_guild_id'),
            payload.get('photo_url'),
        ))
        conn.commit()
        discovery_id = cursor.lastrowid

        logger.info(f"Discovery saved with ID: {discovery_id}")
        return JSONResponse({'status': 'ok', 'discovery_id': discovery_id}, status_code=201)

    except Exception as e:
        logger.error(f"Error saving discovery: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if conn:
            conn.close()


@app.post('/discoveries')
async def legacy_discoveries(payload: dict):
    # Return the same 201 created response as /api/discoveries
    result = await create_discovery(payload)
    if isinstance(result, JSONResponse):
        # If inner function already returned a JSONResponse with 201, just return it
        return result
    # Normalize response to include discovery_id
    if isinstance(result, dict) and 'id' in result:
        return JSONResponse({'status': result.get('status', 'ok'), 'discovery_id': result['id']}, status_code=201)
    return JSONResponse(result, status_code=201)

# Simple WebSocket endpoints for logs and RT-AI
@app.websocket('/ws/logs')
async def ws_logs(ws: WebSocket):
    await ws.accept()
    logpath = LOGS_DIR / 'control-room-web.log'
    try:
        while True:
            await asyncio.sleep(1.0)
            if logpath.exists():
                data = logpath.read_text(encoding='utf-8', errors='ignore')
            else:
                data = ''
            # Check if connection is still open before sending
            try:
                await ws.send_text(data[-1000:])
            except Exception:
                # Connection closed, exit gracefully
                break
    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.error(f'WebSocket /ws/logs error: {e}')
    finally:
        try:
            await ws.close()
        except:
            pass

@app.websocket('/ws/rtai')
async def ws_rtai(ws: WebSocket):
    await ws.accept()
    if not HAVE_RTAI or rtai_instance is None:
        await ws.send_text('RT-AI not available')
        await ws.close()
        return
    await ws.send_text('RT-AI connected')
    try:
        while True:
            await asyncio.sleep(3)
            await ws.send_text('RT-AI heartbeat')
    except WebSocketDisconnect:
        pass

# Allow external init of the RT-AI from other modules
def init_rtai(haven_ui_path: str):
    global rtai_instance
    if not HAVE_RTAI:
        logger.info('Roundtable AI not installed - skipping init')
        return None
    haven_ui_root = Path(haven_ui_path)
    rtai_instance = get_round_table_ai(haven_ui_root)
    return rtai_instance


# ============================================================================
# SYSTEM APPROVALS QUEUE - API Endpoints
# ============================================================================

# Rate limiting storage: IP -> list of submission timestamps
_submission_rate_limits = {}
RATE_LIMIT_SUBMISSIONS = 5  # Max submissions per hour
RATE_LIMIT_WINDOW = 3600  # 1 hour in seconds


def check_rate_limit(ip: str) -> bool:
    """Check if IP has exceeded rate limit. Returns True if allowed, False if blocked."""
    from datetime import timezone
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(seconds=RATE_LIMIT_WINDOW)

    # Clean old entries
    if ip in _submission_rate_limits:
        _submission_rate_limits[ip] = [
            ts for ts in _submission_rate_limits[ip]
            if ts > cutoff
        ]
    else:
        _submission_rate_limits[ip] = []

    # Check count
    if len(_submission_rate_limits[ip]) >= RATE_LIMIT_SUBMISSIONS:
        return False

    # Add new timestamp
    _submission_rate_limits[ip].append(now)
    return True


def validate_system_data(system: dict) -> tuple[bool, str]:
    """Validate system data before accepting submission. Returns (is_valid, error_message)."""
    # Required fields
    if not system.get('name') or not isinstance(system['name'], str) or not system['name'].strip():
        return False, "System name is required"

    # Name length
    if len(system['name']) > 100:
        return False, "System name must be 100 characters or less"

    # Sanitize and validate planets
    if 'planets' in system and system['planets']:
        if not isinstance(system['planets'], list):
            return False, "Planets must be a list"

        for i, planet in enumerate(system['planets']):
            if not isinstance(planet, dict):
                return False, f"Planet {i} is invalid"
            if not planet.get('name') or not planet['name'].strip():
                return False, f"Planet {i} is missing a name"

            # Validate moons if present
            if 'moons' in planet and planet['moons']:
                if not isinstance(planet['moons'], list):
                    return False, f"Planet {i} moons must be a list"
                for j, moon in enumerate(planet['moons']):
                    if not isinstance(moon, dict):
                        return False, f"Planet {i} moon {j} is invalid"
                    if not moon.get('name') or not moon['name'].strip():
                        return False, f"Planet {i} moon {j} is missing a name"

    return True, ""


@app.post('/api/submit_system')
async def submit_system(payload: dict, request: Request):
    """
    Submit a system for approval (non-admin users).
    Accepts system data and queues it for admin review.
    """
    # Get client IP for rate limiting
    client_ip = request.client.host if request.client else "unknown"

    # Check rate limit
    if not check_rate_limit(client_ip):
        raise HTTPException(
            status_code=429,
            detail=f"Rate limit exceeded. Maximum {RATE_LIMIT_SUBMISSIONS} submissions per hour."
        )

    # Validate system data
    is_valid, error_msg = validate_system_data(payload)
    if not is_valid:
        raise HTTPException(status_code=400, detail=error_msg)

    # Extract metadata for indexing
    system_name = payload.get('name', 'Unnamed System')
    system_galaxy = payload.get('galaxy', 'Euclid')
    submitted_by = payload.get('submitted_by', 'Anonymous')

    # Store in pending_systems table
    conn = None
    try:
        db_path = get_db_path()
        # Use standardized connection settings with WAL mode
        conn = get_db_connection()
        cursor = conn.cursor()

        # Check for duplicate submissions (same name, pending status)
        cursor.execute(
            'SELECT id FROM pending_systems WHERE system_name = ? AND status = ?',
            (system_name, 'pending')
        )
        existing = cursor.fetchone()
        if existing:
            raise HTTPException(
                status_code=409,
                detail=f"A pending submission for system '{system_name}' already exists"
            )

        # Insert submission
        from datetime import timezone
        cursor.execute('''
            INSERT INTO pending_systems
            (submitted_by, submitted_by_ip, submission_date, system_data, status, system_name, system_region)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            submitted_by,
            client_ip,
            datetime.now(timezone.utc).isoformat(),
            json.dumps(payload),
            'pending',
            system_name,
            system_galaxy
        ))

        submission_id = cursor.lastrowid
        conn.commit()

        logger.info(f"New system submission: '{system_name}' (ID: {submission_id}) from {client_ip}")

        return {
            'status': 'ok',
            'message': 'System submitted for approval',
            'submission_id': submission_id,
            'system_name': system_name
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error saving submission: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to save submission: {str(e)}")
    finally:
        if conn:
            conn.close()


@app.get('/api/pending_systems')
async def get_pending_systems(session: Optional[str] = Cookie(None)):
    """
    Get all pending system submissions (admin only).
    Returns list of submissions awaiting review.
    """
    # Verify admin session
    if not verify_session(session):
        raise HTTPException(status_code=401, detail="Admin authentication required")

    conn = None
    try:
        db_path = get_db_path()
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT id, submitted_by, submission_date, status, system_name, system_region,
                   reviewed_by, review_date, rejection_reason
            FROM pending_systems
            ORDER BY
                CASE status
                    WHEN 'pending' THEN 1
                    WHEN 'approved' THEN 2
                    WHEN 'rejected' THEN 3
                END,
                submission_date DESC
        ''')

        rows = cursor.fetchall()
        submissions = [dict(row) for row in rows]

        return {'submissions': submissions}

    except Exception as e:
        logger.error(f"Error fetching pending systems: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch submissions: {str(e)}")
    finally:
        if conn:
            conn.close()


@app.get('/api/pending_systems/{submission_id}')
async def get_pending_system_details(submission_id: int, session: Optional[str] = Cookie(None)):
    """
    Get full details of a pending submission including system_data (admin only).
    """
    # Verify admin session
    if not verify_session(session):
        raise HTTPException(status_code=401, detail="Admin authentication required")

    conn = None
    try:
        db_path = get_db_path()
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute('SELECT * FROM pending_systems WHERE id = ?', (submission_id,))
        row = cursor.fetchone()

        if not row:
            raise HTTPException(status_code=404, detail="Submission not found")

        submission = dict(row)
        # Parse JSON system_data
        if submission.get('system_data'):
            submission['system_data'] = json.loads(submission['system_data'])

        return submission

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching submission details: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch submission: {str(e)}")
    finally:
        if conn:
            conn.close()


@app.post('/api/approve_system/{submission_id}')
async def approve_system(submission_id: int, session: Optional[str] = Cookie(None)):
    """
    Approve a pending system submission and add it to the main database (admin only).
    """
    # Verify admin session
    if not verify_session(session):
        raise HTTPException(status_code=401, detail="Admin authentication required")

    conn = None
    try:
        db_path = get_db_path()
        conn = get_db_connection()
        cursor = conn.cursor()

        # Get submission
        cursor.execute('SELECT * FROM pending_systems WHERE id = ?', (submission_id,))
        row = cursor.fetchone()

        if not row:
            raise HTTPException(status_code=404, detail="Submission not found")

        submission = dict(row)

        if submission['status'] != 'pending':
            raise HTTPException(
                status_code=400,
                detail=f"Submission already {submission['status']}"
            )

        # Parse system data
        system_data = json.loads(submission['system_data'])

        # Insert system into main database (same logic as save_system)
        # Insert system
        cursor.execute('''
            INSERT INTO systems (name, galaxy, x, y, z, description, glyph_code, glyph_planet, glyph_solar_system, region_x, region_y, region_z)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            system_data.get('name'),
            system_data.get('galaxy', 'Euclid'),
            system_data.get('x', 0),
            system_data.get('y', 0),
            system_data.get('z', 0),
            system_data.get('description', ''),
            system_data.get('glyph_code'),
            system_data.get('glyph_planet', 0),
            system_data.get('glyph_solar_system', 1),
            system_data.get('region_x'),
            system_data.get('region_y'),
            system_data.get('region_z')
        ))
        system_id = cursor.lastrowid

        # Insert planets
        for planet in system_data.get('planets', []):
            cursor.execute('''
                INSERT INTO planets (system_id, name, x, y, z, sentinel, description)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                system_id,
                planet.get('name'),
                planet.get('x', 0),
                planet.get('y', 0),
                planet.get('z', 0),
                planet.get('sentinel', 'None'),
                planet.get('description', '')
            ))
            planet_id = cursor.lastrowid

            # Insert moons
            for moon in planet.get('moons', []):
                cursor.execute('''
                    INSERT INTO moons (planet_id, name, orbit_radius, sentinel, description)
                    VALUES (?, ?, ?, ?, ?)
                ''', (
                    planet_id,
                    moon.get('name'),
                    moon.get('orbit_radius', 0.5),
                    moon.get('sentinel', 'None'),
                    moon.get('description', '')
                ))

        # Insert space station if present
        if system_data.get('space_station'):
            station = system_data['space_station']
            cursor.execute('''
                INSERT INTO space_stations (system_id, name, race, x, y, z, sell_percent, buy_percent)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                system_id,
                station.get('name', f"{system_data.get('name')} Station"),
                station.get('race', 'Gek'),
                station.get('x', 0),
                station.get('y', 0),
                station.get('z', 0),
                station.get('sell_percent', 80),
                station.get('buy_percent', 50)
            ))

        # Mark submission as approved
        from datetime import timezone
        cursor.execute('''
            UPDATE pending_systems
            SET status = ?, reviewed_by = ?, review_date = ?
            WHERE id = ?
        ''', ('approved', 'admin', datetime.now(timezone.utc).isoformat(), submission_id))

        conn.commit()

        logger.info(f"Approved system submission: '{system_data.get('name')}' (ID: {submission_id})")

        return {
            'status': 'ok',
            'message': 'System approved and added to database',
            'system_id': system_id,
            'system_name': system_data.get('name')
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error approving submission: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to approve submission: {str(e)}")
    finally:
        if conn:
            conn.close()


@app.post('/api/reject_system/{submission_id}')
async def reject_system(submission_id: int, payload: dict, session: Optional[str] = Cookie(None)):
    """
    Reject a pending system submission with reason (admin only).
    """
    # Verify admin session
    if not verify_session(session):
        raise HTTPException(status_code=401, detail="Admin authentication required")

    reason = payload.get('reason', 'No reason provided')

    conn = None
    try:
        db_path = get_db_path()
        conn = get_db_connection()
        cursor = conn.cursor()

        # Check submission exists and is pending
        cursor.execute('SELECT status, system_name FROM pending_systems WHERE id = ?', (submission_id,))
        row = cursor.fetchone()

        if not row:
            raise HTTPException(status_code=404, detail="Submission not found")

        status, system_name = row

        if status != 'pending':
            raise HTTPException(
                status_code=400,
                detail=f"Submission already {status}"
            )

        # Mark as rejected
        from datetime import timezone
        cursor.execute('''
            UPDATE pending_systems
            SET status = ?, reviewed_by = ?, review_date = ?, rejection_reason = ?
            WHERE id = ?
        ''', ('rejected', 'admin', datetime.now(timezone.utc).isoformat(), reason, submission_id))

        conn.commit()

        logger.info(f"Rejected system submission: '{system_name}' (ID: {submission_id}). Reason: {reason}")

        return {
            'status': 'ok',
            'message': 'System submission rejected',
            'submission_id': submission_id
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error rejecting submission: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to reject submission: {str(e)}")
    finally:
        if conn:
            conn.close()


@app.get('/api/pending_systems/count')
async def get_pending_count():
    """
    Get count of pending submissions (public endpoint for badge display).
    """
    conn = None
    try:
        db_path = get_db_path()
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT COUNT(*) FROM pending_systems WHERE status = 'pending'")
        count = cursor.fetchone()[0]

        return {'count': count}

    except Exception as e:
        logger.error(f"Error getting pending count: {e}")
        return {'count': 0}
    finally:
        if conn:
            conn.close()


if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=8005)
