import React, { useEffect, useState, useContext } from 'react'
import axios from 'axios'
import { useLocation, useNavigate } from 'react-router-dom'
import Card from '../components/Card'
import Button from '../components/Button'
import PlanetEditor from '../components/PlanetEditor'
import Modal from '../components/Modal'
import GlyphPicker from '../components/GlyphPicker'
import { AuthContext } from '../utils/AuthContext'
import { generateRandomStationPosition } from '../utils/stationPlacement'

function useQuery(){ return new URLSearchParams(useLocation().search) }

export default function Wizard(){
  const query = useQuery();
  const navigate = useNavigate();
  const auth = useContext(AuthContext)
  const isAdmin = auth?.isAdmin || false
  const edit = query.get('edit')
  const [system, setSystem] = useState({ id:'', name:'', galaxy:'Euclid', glyph_code:'', x:'', y:'', z:'', description:'', planets: [], space_station: null, region_x: null, region_y: null, region_z: null, glyph_planet: 0, glyph_solar_system: 1 })
  const [planetModalOpen, setPlanetModalOpen] = useState(false)
  const [editingPlanetIndex, setEditingPlanetIndex] = useState(null)
  const [editingPlanet, setEditingPlanet] = useState(null)
  const [hasStation, setHasStation] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(()=>{ if(edit){ axios.get(`/api/systems/${encodeURIComponent(edit)}`).then(r=>setSystem(r.data)).catch(()=>{}) } }, [edit])

  async function submit(e){ e.preventDefault();
    // Client-side validation for nested planets & moons
    if(!system.name || !system.name.trim()) { alert('System name is required'); return; }
    if(system.planets){
      for(const p of system.planets){
        if(!p.name || !p.name.trim()){ alert('All planets must have a name'); return; }
        if(p.moons){
          for(const m of p.moons){
            if(!m.name || !m.name.trim()){ alert('All moons must have a name'); return; }
          }
        }
      }
    }

    setIsSubmitting(true)
    try{
      if(isAdmin){
        // Admin: save directly to database
        const r = await axios.post('/api/save_system', system);
        alert('System saved successfully!');
        navigate('/systems');
      } else {
        // Non-admin: submit for approval
        const r = await axios.post('/api/submit_system', system);
        alert(`System submitted for approval!\n\nSubmission ID: ${r.data.submission_id}\nSystem Name: ${r.data.system_name}\n\nAn admin will review your submission.`);
        navigate('/systems');
      }
    } catch(err){
      const errorMsg = err.response?.data?.detail || err.message || err;
      alert(`${isAdmin ? 'Save' : 'Submission'} failed: ${errorMsg}`);
    } finally {
      setIsSubmitting(false)
    }
  }

  // Prevent accidental submits from pressing Enter in text inputs.
  // Allow Enter for textareas and when focused on the actual submit button.
  function handleKeyDown(e){
    if(e.key === 'Enter'){
      const tag = (e.target && e.target.tagName) ? e.target.tagName.toUpperCase() : '';
      const type = (e.target && e.target.type) ? String(e.target.type).toLowerCase() : '';
      if(tag === 'TEXTAREA') return; // allow new line
      if(type === 'submit' || tag === 'BUTTON') return; // allow submitting via button or submit element
      // Otherwise, prevent the Enter key from submitting the form
      e.preventDefault();
    }
  }

  function setField(k,v){ setSystem(s => ({...s, [k]: v})) }

  function handleGlyphDecoded(decodedData) {
    // Update system with decoded coordinates and region info
    setSystem(s => ({
      ...s,
      x: decodedData.x,
      y: decodedData.y,
      z: decodedData.z,
      region_x: decodedData.region_x,
      region_y: decodedData.region_y,
      region_z: decodedData.region_z,
      glyph_planet: decodedData.planet,
      glyph_solar_system: decodedData.solar_system,
      glyph_code: decodedData.glyph
    }))
  }

  function addPlanet(){
    setEditingPlanetIndex(-1)
    setEditingPlanet({ name: '', sentinel: 'None', moons: [] })
    setPlanetModalOpen(true)
  }

  function editPlanet(i){
    setEditingPlanetIndex(i)
    setEditingPlanet(system.planets[i])
    setPlanetModalOpen(true)
  }

  function commitPlanet(planet){
    const planets = [...(system.planets || [])]
    if(editingPlanetIndex === -1){
      planets.push(planet)
    } else {
      planets[editingPlanetIndex] = planet
    }
    setSystem({...system, planets})
    setPlanetModalOpen(false)
  }

  function updatePlanet(idx, val){
    const planets = [...(system.planets || [])]
    planets[idx] = val
    setSystem({...system, planets})
  }

  function removePlanet(idx){
    const planets = [...(system.planets || [])]
    planets.splice(idx, 1)
    setSystem({...system, planets})
  }

  function toggleStation(checked){
    setHasStation(checked)
    if(checked){
      // Generate random position for station
      const position = generateRandomStationPosition(system.planets || [])
      setSystem({...system, space_station: {
        name: `${system.name || 'System'} Station`,
        race: 'Gek',
        sell_percent: 80,
        buy_percent: 50,
        ...position
      }})
    } else {
      setSystem({...system, space_station: null})
    }
  }

  function regenerateStationPosition(){
    if(hasStation && system.space_station){
      const position = generateRandomStationPosition(system.planets || [])
      setSystem({...system, space_station: {
        ...system.space_station,
        ...position
      }})
      alert(`New position generated:\nX: ${position.x}\nY: ${position.y}\nZ: ${position.z}\nAttempts: ${position.attempts}${position.fallback ? ' (fallback used)' : ''}`)
    }
  }

  function setStationField(k,v){
    if(system.space_station){
      setSystem({...system, space_station: {...system.space_station, [k]: v}})
    }
  }

  return (
    <div>
      <Card className="max-w-4xl">
        <form onSubmit={submit} onKeyDown={handleKeyDown}>
        <label className="block mb-2">System Name <input placeholder="Name" aria-label="Name" className="w-full mt-1" value={system.name || ''} onChange={e=>setField('name', e.target.value)} required/></label>

        <div className="mt-4">
          <h3 className="text-lg font-semibold mb-2 text-purple-300">Portal Glyph Coordinates</h3>
          <GlyphPicker
            value={system.glyph_code}
            onChange={(code) => setField('glyph_code', code)}
            onDecoded={handleGlyphDecoded}
          />
        </div>

        {/* Display decoded coordinates (read-only) */}
        {system.x && system.y && system.z && (
          <div className="mt-4 p-3 bg-gray-800 rounded border border-green-500">
            <div className="text-sm text-gray-300">
              <span className="text-green-300 font-semibold">Coordinates:</span> X: {system.x}, Y: {system.y}, Z: {system.z}
              {system.region_x !== null && (
                <span className="ml-3">
                  <span className="text-purple-300 font-semibold">Region:</span> [{system.region_x}, {system.region_y}, {system.region_z}]
                </span>
              )}
            </div>
          </div>
        )}

        <label className="block mt-3">Galaxy <input placeholder="Galaxy" className="w-full mt-1" value={system.galaxy || 'Euclid'} onChange={e=>setField('galaxy', e.target.value)} /></label>
        <label className="block mt-3">Description <textarea aria-label="System description" className="w-full mt-1" value={system.description || ''} onChange={e=>setField('description', e.target.value)} /></label>
        <div className="mt-4">
          <h3 className="text-md font-semibold mb-2">Planets</h3>
          <div>
            {(system.planets || []).map((p, i) => (
              <div key={i} className="mb-2">
                <PlanetEditor index={i} planet={p} onChange={updatePlanet} onRemove={removePlanet} />
                <div className="mt-1 flex space-x-2">
                  <button className="px-3 py-1 bg-sky-600 text-white rounded" onClick={() => editPlanet(i)}>Edit</button>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-2">
            <button type="button" onClick={addPlanet} className="px-3 py-1 bg-green-600 rounded">➕ Add Planet</button>
          </div>
        </div>

        <div className="mt-4 border-t pt-4">
          <h3 className="text-md font-semibold mb-2">Space Station</h3>
          <label className="flex items-center space-x-2 mb-3">
            <input
              type="checkbox"
              checked={hasStation}
              onChange={(e) => toggleStation(e.target.checked)}
              className="w-4 h-4"
            />
            <span>🛸 Has Space Station (randomly placed)</span>
          </label>

          {hasStation && system.space_station && (
            <div className="ml-6 p-3 bg-purple-50 rounded border border-purple-200">
              <div className="mb-2">
                <label className="block text-sm">Station Name</label>
                <input
                  className="w-full mt-1"
                  value={system.space_station.name || ''}
                  onChange={(e) => setStationField('name', e.target.value)}
                  placeholder="Station Name"
                />
              </div>

              <div className="mb-2">
                <label className="block text-sm">Race</label>
                <select
                  className="w-full mt-1"
                  value={system.space_station.race || 'Gek'}
                  onChange={(e) => setStationField('race', e.target.value)}
                >
                  <option value="Gek">Gek</option>
                  <option value="Korvax">Korvax</option>
                  <option value="Vy'keen">Vy'keen</option>
                  <option value="Unknown">Unknown</option>
                </select>
              </div>

              <div className="grid grid-cols-3 gap-2 mb-2">
                <div>
                  <label className="block text-sm">X</label>
                  <input
                    type="number"
                    step="0.1"
                    className="w-full mt-1 bg-gray-100"
                    value={system.space_station.x || 0}
                    onChange={(e) => setStationField('x', parseFloat(e.target.value))}
                    readOnly={false}
                  />
                </div>
                <div>
                  <label className="block text-sm">Y</label>
                  <input
                    type="number"
                    step="0.1"
                    className="w-full mt-1 bg-gray-100"
                    value={system.space_station.y || 0}
                    onChange={(e) => setStationField('y', parseFloat(e.target.value))}
                    readOnly={false}
                  />
                </div>
                <div>
                  <label className="block text-sm">Z</label>
                  <input
                    type="number"
                    step="0.1"
                    className="w-full mt-1 bg-gray-100"
                    value={system.space_station.z || 0}
                    onChange={(e) => setStationField('z', parseFloat(e.target.value))}
                    readOnly={false}
                  />
                </div>
              </div>

              <button
                type="button"
                onClick={regenerateStationPosition}
                className="px-3 py-1 bg-purple-600 text-white rounded text-sm"
              >
                🎲 Regenerate Random Position
              </button>

              {system.space_station.fallback && (
                <div className="mt-2 text-xs text-yellow-700 bg-yellow-100 p-2 rounded">
                  ⚠️ Fallback position used - couldn't find collision-free spot after 100 attempts
                </div>
              )}
            </div>
          )}
        </div>

        <div className="mt-4 flex flex-col space-y-2">
          {!isAdmin && (
            <div className="text-sm text-yellow-700 bg-yellow-100 p-2 rounded">
              Note: You are not logged in as admin. Your system will be submitted for approval.
            </div>
          )}
          <div className="flex space-x-2">
            <Button className="btn-primary" type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Submitting...' : (isAdmin ? 'Save System' : 'Submit for Approval')}
            </Button>
            <Button className="bg-gray-200 text-gray-800" onClick={()=> navigate('/systems')} disabled={isSubmitting}>Cancel</Button>
          </div>
        </div>
        {planetModalOpen && (
        <Modal title={editingPlanetIndex === -1 ? 'Add Planet' : 'Edit Planet'} onClose={() => setPlanetModalOpen(false)}>
          <PlanetEditor planet={editingPlanet} index={editingPlanetIndex} onChange={(i,p)=>{ setEditingPlanet(p) }} onRemove={() => {}} onSave={commitPlanet} />
        </Modal>
      )}
        </form>
      </Card>
    </div>
  )
}
